#ifndef ENGINE_H
#define ENGINE_H

void performComputation(int arr[], int size);
bool executeMenu(int choice, int*& arr, int& size);
int selectMenu();

#endif