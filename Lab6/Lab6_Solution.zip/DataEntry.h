#ifndef DATAENTRY_H
#define DATAENTRY_H

void performDataEntry(int*& arr, int& n);

#endif