#ifndef SORT_H
#define SORT_H

void performQuickSort(int arr[], int left, int right);
void performSortMarks(int arr[], const int& size);

#endif