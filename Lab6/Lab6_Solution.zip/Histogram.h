#ifndef HISTOGRAM_H
#define HISTOGRAM_H

void performHistogram(int arr[], int size);

#endif