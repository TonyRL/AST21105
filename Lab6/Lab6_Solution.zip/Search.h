#ifndef SEARCH_H
#define SEARCH_H

int performBinarySearch(int arr[], int left, int right, int key);
void performSearchMark(int arr[], const int& size);

#endif